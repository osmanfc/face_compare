import argparse
import face_recognition
import numpy as np
import sys
import cv2
import pytesseract
import dlib

def compare_faces_v1(image_path_a, image_path_b):
    similarity_threshold=100
    # Load the face detector
    face_detector = dlib.get_frontal_face_detector()
    
    # Load the images
    selfie_image = cv2.imread(image_path_a)
    group_photo = cv2.imread(image_path_b)

    if selfie_image is None or group_photo is None:
        raise ValueError("One or both images could not be loaded. Check file paths.")

    # Detect faces
    selfie_faces = face_detector(selfie_image, 1)
    group_faces = face_detector(group_photo, 1)

    # Compare detected faces
    for selfie_face in selfie_faces:
        for group_face in group_faces:
            distance = (
                abs(selfie_face.left() - group_face.left()) +
                abs(selfie_face.right() - group_face.right()) +
                abs(selfie_face.top() - group_face.top()) +
                abs(selfie_face.bottom() - group_face.bottom())
            )
            if distance < similarity_threshold:
                return True
    return False


def get_face_encoding(image_path):
    """Extract the first face encoding from an image (HOG model, tolerant for low-quality)"""
    # Load image
    image = preprocess_image(image_path)
    if image is None:
        print(f"[ERROR] Unable to load {image_path}")
        return None

    # Detect face locations using HOG + upsample
    face_locations = face_recognition.face_locations(image, model="hog", number_of_times_to_upsample=2)
    if not face_locations:
        print(f"[ERROR] No face detected in {image_path}")
        return None

    # Get encodings for detected faces
    encodings = face_recognition.face_encodings(image, known_face_locations=face_locations)
    if not encodings:
        print(f"[ERROR] Unable to encode face in {image_path}")
        return None

    return encodings[0]  # return first face encoding


def compare_faces(img1, img2, threshold=0.6):
    """Compare two images with enhanced error handling"""
    print(f"Processing {img1}...")
    enc1 = get_face_encoding(img1)
    
    print(f"Processing {img2}...")
    enc2 = get_face_encoding(img2)

    if enc1 is None or enc2 is None:
        print("[ERROR] Could not process one or both images")
        return None

    # Calculate face distance (lower is better)
    distance = face_recognition.face_distance([enc1], enc2)[0]
    
    # Convert to confidence percentage
    confidence = max(0, (1 - distance) * 100)
    
    # Check if distance is below threshold for match
    is_match = distance < threshold
    
    return {
        'confidence': confidence,
        'distance': distance,
        'is_match': is_match,
        'threshold': threshold
    }


def preprocess_image(path):
    img = cv2.imread(path)
    if img is None:
        return None
    # Resize to width=800 while keeping aspect ratio
    h, w = img.shape[:2]
    scale = 800 / w
    img = cv2.resize(img, (0, 0), fx=scale, fy=scale)

    # Convert to RGB for face_recognition
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    return img


def extract_text_from_image(image_path, lang="eng+ben",type="auto"):
    tessdata_dir = "/usr/local/facecompare/main/tessdata"
    save_path = adjust_brightness_contrast(image_path, "/root/nid_card_processed3.png")
    img = cv2.imread(image_path)
    if img is None:
        return None
    if type=="auto":    
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        custom_config = f'--tessdata-dir "{tessdata_dir}" -l {lang} --oem 3 --psm 3'
        text = pytesseract.image_to_string(gray, config=custom_config)
    if type=="v1":
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        thresh = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
        custom_config = f'--tessdata-dir "{tessdata_dir}" -l {lang} --oem 3 --psm 3'
        text = pytesseract.image_to_string(thresh, config=custom_config)
        
    if type=="v2":
        custom_config = f'--tessdata-dir "{tessdata_dir}" -l {lang} --oem 3 --psm 3'
        img = cv2.imread("/root/nid_card_processed3.png")
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        text = pytesseract.image_to_string(img, config=custom_config)
    
    
        
        
        
        
        
    return text.strip()
    
    


def enhance_and_save_image_soft(image_path, output_path):
    img = cv2.imread(image_path)
    if img is None:
        print("Image not found!")
        return None

    # Convert to LAB color space (L = lightness)
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)

    # Split channels
    l, a, b = cv2.split(lab)

    # Apply CLAHE on L channel (contrast enhancement)
    clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8,8))
    l = clahe.apply(l)

    # Merge channels back
    enhanced_lab = cv2.merge((l, a, b))

    # Convert back to BGR
    enhanced_img = cv2.cvtColor(enhanced_lab, cv2.COLOR_LAB2BGR)

    # Optional: mild sharpening (helps OCR on blurry text)
    kernel = np.array([[0,-1,0], [-1,5,-1], [0,-1,0]])
    enhanced_img = cv2.filter2D(enhanced_img, -1, kernel)

    # Save result
    cv2.imwrite(output_path, enhanced_img)
    return output_path
    
    
def adjust_brightness_contrast(image_path, output_path, contrast_percent=15, brightness_percent=-20):
    """
    Increase contrast and reduce brightness for deeper colors and sharper text.
    contrast_percent: positive = more contrast
    brightness_percent: negative = darker, positive = brighter
    """
    img = cv2.imread(image_path)
    if img is None:
        print("Image not found!")
        return None

    # Contrast factor
    alpha = 1 + (contrast_percent / 100.0)

    # Brightness shift
    beta = (brightness_percent / 100.0) * 255

    # Apply adjustment
    adjusted = cv2.convertScaleAbs(img, alpha=alpha, beta=beta)

    cv2.imwrite(output_path, adjusted)
    return output_path
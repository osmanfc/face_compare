from django.urls import path
from .views import *
from . import views
urlpatterns = [
    path('', home, name='home'),
    path('verify/', verify, name='verify'),
    path('ocr/', ocr, name='ocr'),
    path('face_compare_v1/', face_compare_v1, name='face_compare_v1'),
   

]

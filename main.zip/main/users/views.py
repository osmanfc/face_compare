import json
import os
import tempfile
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.contrib.auth.views import LoginView, PasswordResetView, PasswordChangeView
from django.contrib import messages
from django.contrib.messages.views import SuccessMessageMixin
from django.views import View
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .forms import RegisterForm, LoginForm, UpdateUserForm, UpdateProfileForm
from .core import *
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
from .decorators import * 

ALLOWED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/jpg", "image/bmp", "image/webp"]
ALLOWED_EXTENSIONS = [".jpg", ".jpeg", ".png", ".bmp", ".webp"]

def home(request):
    return render(request, 'users/home.html')


class RegisterView(View):
    form_class = RegisterForm
    initial = {'key': 'value'}
    template_name = 'users/register.html'

    def dispatch(self, request, *args, **kwargs):
        # will redirect to the home page if a user tries to access the register page while logged in
        if request.user.is_authenticated:
            return redirect(to='/')

        # else process dispatch as it otherwise normally would
        return super(RegisterView, self).dispatch(request, *args, **kwargs)

    def get(self, request, *args, **kwargs):
        form = self.form_class(initial=self.initial)
        return render(request, self.template_name, {'form': form})

    def post(self, request, *args, **kwargs):
        form = self.form_class(request.POST)

        if form.is_valid():
            form.save()

            username = form.cleaned_data.get('username')
            messages.success(request, f'Account created for {username}')

            return redirect(to='login')

        return render(request, self.template_name, {'form': form})


# Class based view that extends from the built in login view to add a remember me functionality
class CustomLoginView(LoginView):
    form_class = LoginForm

    def form_valid(self, form):
        remember_me = form.cleaned_data.get('remember_me')

        if not remember_me:
            # set session expiry to 0 seconds. So it will automatically close the session after the browser is closed.
            self.request.session.set_expiry(0)

            # Set session as modified to force data updates/cookie to be saved.
            self.request.session.modified = True

        # else browser session will be as long as the session cookie time "SESSION_COOKIE_AGE" defined in settings.py
        return super(CustomLoginView, self).form_valid(form)


class ResetPasswordView(SuccessMessageMixin, PasswordResetView):
    template_name = 'users/password_reset.html'
    email_template_name = 'users/password_reset_email.html'
    subject_template_name = 'users/password_reset_subject'
    success_message = "We've emailed you instructions for setting your password, " \
                      "if an account exists with the email you entered. You should receive them shortly." \
                      " If you don't receive an email, " \
                      "please make sure you've entered the address you registered with, and check your spam folder."
    success_url = reverse_lazy('users-home')


class ChangePasswordView(SuccessMessageMixin, PasswordChangeView):
    template_name = 'users/change_password.html'
    success_message = "Successfully Changed Your Password"
    success_url = reverse_lazy('users-home')


@login_required
def profile(request):
    if request.method == 'POST':
        user_form = UpdateUserForm(request.POST, instance=request.user)
        profile_form = UpdateProfileForm(request.POST, request.FILES, instance=request.user.profile)

        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_form.save()
            messages.success(request, 'Your profile is updated successfully')
            return redirect(to='users-profile')
    else:
        user_form = UpdateUserForm(instance=request.user)
        profile_form = UpdateProfileForm(instance=request.user.profile)

    return render(request, 'users/profile.html', {'user_form': user_form, 'profile_form': profile_form})
    
    
    
@csrf_exempt
@api_login_required
def verify(request):
    if request.method != "POST":
        return JsonResponse({"error": "Only POST allowed"}, status=405)

    if request.content_type.startswith("multipart/"):
        img1 = request.FILES.get("image1")
        img2 = request.FILES.get("image2")
        if not img1 or not img2:
            return JsonResponse({"error": "Both image1 and image2 required"}, status=400)

        # --- Validate img1 ---
        if img1.content_type not in ALLOWED_IMAGE_TYPES:
            return JsonResponse({"error": "image1 must be an image"}, status=400)
        ext1 = os.path.splitext(img1.name)[1].lower()
        if ext1 not in ALLOWED_EXTENSIONS:
            return JsonResponse({"error": "Unsupported image1 file extension"}, status=400)

        # --- Validate img2 ---
        if img2.content_type not in ALLOWED_IMAGE_TYPES:
            return JsonResponse({"error": "image2 must be an image"}, status=400)
        ext2 = os.path.splitext(img2.name)[1].lower()
        if ext2 not in ALLOWED_EXTENSIONS:
            return JsonResponse({"error": "Unsupported image2 file extension"}, status=400)


        # Save uploaded files to temporary files
        temp_files = []
        try:
            for uploaded_file in [img1, img2]:
                temp = tempfile.NamedTemporaryFile(delete=False, suffix=".jpg")
                for chunk in uploaded_file.chunks():
                    temp.write(chunk)
                temp.close()
                temp_files.append(temp.name)

            # Compare faces
            result = compare_faces(temp_files[0], temp_files[1], 0.6)

            if result is None:
                response_data = {
                    "confidence": 0.0,
                    "distance": None,
                    "is_match": False,
                    "threshold": 0.6,
                    "error": "Could not detect face(s)"
                }
                status_code = 400
            else:
                # Ensure JSON-serializable types
                response_data = {
                    "confidence": float(result.get("confidence", 0)),
                    "distance": float(result.get("distance", 0)),
                    "is_match": bool(result.get("is_match", False)),
                    "threshold": float(result.get("threshold", 0.6))
                }
                status_code = 200

            return JsonResponse(response_data, status=status_code)

        finally:
            # Clean up temp files
            for f in temp_files:
                if os.path.exists(f):
                    os.remove(f)

    return JsonResponse({"error": "Unsupported content type"}, status=400)
    
    
    
@csrf_exempt
@api_login_required
def ocr(request):
    if request.method != "POST":
        return JsonResponse({"error": "Only POST allowed"}, status=405)

    if "image" not in request.FILES:
        return JsonResponse({"error": "No image uploaded"}, status=400)

    img_file = request.FILES["image"]
    if img_file.content_type not in ALLOWED_IMAGE_TYPES:
        return JsonResponse({"error": "Only image files are allowed"}, status=400)
        
    ext = os.path.splitext(img_file.name)[1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        return JsonResponse({"error": "Unsupported file extension"}, status=400)    

    type = request.POST.get("type", "auto")
    # Save uploaded file temporarily
    with tempfile.NamedTemporaryFile(delete=False, suffix=".jpg") as tmp_file:
        for chunk in img_file.chunks():
            tmp_file.write(chunk)
        image_path = tmp_file.name

    try:
        text = extract_text_from_image(image_path,type=type)
        # Use json.dumps to preserve actual newlines in response
        return HttpResponse(
            json.dumps({"text": text}, ensure_ascii=False),
            content_type="application/json"
        )
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)
    finally:
        if os.path.exists(image_path):
            os.unlink(image_path)
            
            
            
@csrf_exempt
@api_login_required
def face_compare_v1(request):
    if request.method == "POST":
        selfie_file = request.FILES.get("image1")
        group_file = request.FILES.get("image2")
        
    if selfie_file.content_type not in ALLOWED_IMAGE_TYPES:
        return JsonResponse({"error": "Selfie file must be an image."}, status=400)

    ext_selfie = os.path.splitext(selfie_file.name)[1].lower()
    if ext_selfie not in ALLOWED_EXTENSIONS:
        return JsonResponse({"error": "Unsupported selfie file extension."}, status=400)

    # --- Validate group_file ---
    if group_file.content_type not in ALLOWED_IMAGE_TYPES:
        return JsonResponse({"error": "Group file must be an image."}, status=400)

    ext_group = os.path.splitext(group_file.name)[1].lower()
    if ext_group not in ALLOWED_EXTENSIONS:
        return JsonResponse({"error": "Unsupported group file extension."}, status=400)
        

        if not selfie_file or not group_file:
            return JsonResponse({"error": "Both images are required."}, status=400)

        # Save uploaded files temporarily
        selfie_path = default_storage.save("temp_selfie.jpg", ContentFile(selfie_file.read()))
        group_path = default_storage.save("temp_group.jpg", ContentFile(group_file.read()))

        try:
            match = compare_faces_v1(
                default_storage.path(selfie_path),
                default_storage.path(group_path)
            )
        except Exception as e:
            return JsonResponse({"error": str(e)}, status=500)
        finally:
            # Clean up temporary files
            default_storage.delete(selfie_path)
            default_storage.delete(group_path)

        return JsonResponse({"match": "yes" if match else "no"})

    return JsonResponse({"error": "POST request required."}, status=400)            
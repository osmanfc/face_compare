import configparser
from django.contrib.auth import authenticate
from django.http import JsonResponse
from functools import wraps
import os
from django.conf import settings
    

# Django root path (project base directory)
PROJECT_API_KEY_FILE = os.path.join(settings.BASE_DIR, "etc", "apikey.txt")

def get_saved_api_key():
    """Read API key only from Django project root"""
    if os.path.exists(PROJECT_API_KEY_FILE):
        try:
            with open(PROJECT_API_KEY_FILE, "r") as f:
                return f.read().strip()
        except Exception:
            return None
    return None

def api_login_required(view_func):
    @wraps(view_func)
    def _wrapped_view(request, *args, **kwargs):
       
        # Only POST allowed
        if request.method != 'POST':
            return JsonResponse({'error': 'POST method required'}, status=200)

        # API key from POST or header
        apikey = request.POST.get('apikey') or request.headers.get("X-Api-Key")
        if not apikey:
            return JsonResponse({'error': 'API key required'}, status=200)

        # Load saved key
        saved_key = get_saved_api_key()
        if not saved_key:
            return JsonResponse({'error': 'API key not configured'}, status=200)

        # Compare keys
        if apikey != saved_key:
            return JsonResponse({'error': 'Invalid API key'}, status=200)

        # Passed -> call view
        return view_func(request, *args, **kwargs)

    return _wrapped_view